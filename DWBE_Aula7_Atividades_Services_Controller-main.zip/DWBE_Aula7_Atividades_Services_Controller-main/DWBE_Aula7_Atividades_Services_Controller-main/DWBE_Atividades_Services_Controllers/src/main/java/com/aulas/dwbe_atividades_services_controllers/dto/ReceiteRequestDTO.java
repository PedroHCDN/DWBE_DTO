package com.aulas.dwbe_atividades_services_controllers.dto;

import com.aulas.dwbe_atividades_services_controllers.model.Consulta;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ReceiteRequestDTO {
    private Long id;
    private String medicamento;
    private String dosagem;
    private Integer duracaoDias;
    private Consulta consulta;
}
