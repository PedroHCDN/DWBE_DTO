package com.aulas.dwbe_atividades_services_controllers.controller;

import com.aulas.dwbe_atividades_services_controllers.model.Consulta;
import com.aulas.dwbe_atividades_services_controllers.service.ConsultaService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/consulta")
public class ConsultaController {
    private ConsultaService consultaService;

    public ConsultaController(ConsultaService consultaService) {
        this.consultaService = consultaService;
    }

    @PostMapping
    public Consulta salvarConsulta(@RequestBody Consulta consulta) {
        return this.consultaService.salvar(consulta);
    }

    @GetMapping
    public List<Consulta> todasConsultas() {
        return this.consultaService.todos();
    }

    @GetMapping("/{id}")
    public Consulta consultaPorId (@PathVariable Long id) {
        return this.consultaService.porId(id);
    }

    @PutMapping("{id}")
    public Consulta atualizaConsulta(@PathVariable Long id, @RequestBody Consulta consulta) {
        return this.consultaService.atualizar(id, consulta);
    }

    @DeleteMapping("{id}")
    public boolean excluirConsulta(@PathVariable Long id) {
        return this.consultaService.excluir(id);
    }
}
