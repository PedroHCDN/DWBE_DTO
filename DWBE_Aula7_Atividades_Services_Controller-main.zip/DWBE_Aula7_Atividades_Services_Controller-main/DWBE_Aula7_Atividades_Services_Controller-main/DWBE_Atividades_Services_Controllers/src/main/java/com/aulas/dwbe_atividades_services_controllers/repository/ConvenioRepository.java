package com.aulas.dwbe_atividades_services_controllers.repository;

import com.aulas.dwbe_atividades_services_controllers.model.Consulta;
import com.aulas.dwbe_atividades_services_controllers.model.Convenio;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ConvenioRepository extends JpaRepository<Convenio, Long> {
}
