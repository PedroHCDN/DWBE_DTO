package com.aulas.dwbe_atividades_services_controllers.service;

import com.aulas.dwbe_atividades_services_controllers.dto.ConvenioRequestDTO;
import com.aulas.dwbe_atividades_services_controllers.dto.ConvenioResponseDTO;
import com.aulas.dwbe_atividades_services_controllers.dto.MedicoRequestDTO;
import com.aulas.dwbe_atividades_services_controllers.model.Consulta;
import com.aulas.dwbe_atividades_services_controllers.model.Convenio;
import com.aulas.dwbe_atividades_services_controllers.model.Medico;
import com.aulas.dwbe_atividades_services_controllers.repository.ConsultaRepository;
import com.aulas.dwbe_atividades_services_controllers.repository.ConvenioRepository;
import com.aulas.dwbe_atividades_services_controllers.repository.MedicoRepository;

import java.util.List;

public class MedicoService {
    private MedicoRepository medicoRepository;
    private ConsultaRepository consultaRepository;

    public MedicoService(MedicoRepository medicoRepository, ConsultaRepository consultaRepository){
        this.medicoRepository = medicoRepository;
        this.consultaRepository = consultaRepository;
    }

    private Medico toEntity(MedicoRequestDTO medicoRequestDTO){
        Medico user = new Medico();
        user.setNome(medicoRequestDTO.getNome());
        user.setCnpj(convenioRequestDTO.getCnpj());
        return user;
    }

    private ConvenioResponseDTO toDTO(Convenio convenio){
        return ConvenioResponseDTO.builder()
                .id(convenio.getId())
                .nome(convenio.getNome())
                .cnpj(convenio.getCnpj())
                .build();
    }

    public ConvenioResponseDTO salvar(ConvenioRequestDTO convenioRequestDTO){
        //Nada pra verifica, ja que não tem obrigatorio
        Convenio convenio = toEntity(convenioRequestDTO);
        Convenio convenioSalvo = this.convenioRepository.save(convenio);
        return toDTO(convenioSalvo);
    }

    public List<ConvenioResponseDTO> todos(){
        return this.convenioRepository.findAll()
                .stream()
                .map(this :: toDTO)
                .toList();
    }

    public ConvenioResponseDTO porId(Long id){
        Convenio convenio = this.convenioRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Convenio não encontrado"));
        return toDTO(convenio);
    }

    public ConvenioResponseDTO atualizar(Long id, ConvenioRequestDTO dto){
        Convenio convenio = convenioRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Convenio não encontrado"));
        convenio.setNome(dto.getNome());
        convenio.setCnpj(dto.getCnpj());
        Convenio atualizado = convenioRepository.save(convenio);
        return toDTO(atualizado);
    }

    public String exclui(Long id){
        Convenio convenio = this.convenioRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Convenio não encontrado"));
        this.convenioRepository.delete(convenio);
        return "Excluído com sucesso";
    }
}
