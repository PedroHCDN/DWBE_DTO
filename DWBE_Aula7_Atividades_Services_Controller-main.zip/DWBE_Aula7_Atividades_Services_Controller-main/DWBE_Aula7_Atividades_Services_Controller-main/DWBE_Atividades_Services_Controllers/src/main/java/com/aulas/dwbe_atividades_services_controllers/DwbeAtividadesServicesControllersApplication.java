package com.aulas.dwbe_atividades_services_controllers;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DwbeAtividadesServicesControllersApplication {

    public static void main(String[] args) {
        SpringApplication.run(DwbeAtividadesServicesControllersApplication.class, args);
    }

}
