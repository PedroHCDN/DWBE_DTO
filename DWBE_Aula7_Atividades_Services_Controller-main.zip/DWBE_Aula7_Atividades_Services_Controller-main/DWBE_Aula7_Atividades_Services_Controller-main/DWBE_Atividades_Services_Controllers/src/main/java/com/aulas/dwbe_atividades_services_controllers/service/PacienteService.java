package com.aulas.dwbe_atividades_services_controllers.service;

import com.aulas.dwbe_atividades_services_controllers.model.Consulta;
import com.aulas.dwbe_atividades_services_controllers.model.Medico;
import com.aulas.dwbe_atividades_services_controllers.model.Paciente;
import com.aulas.dwbe_atividades_services_controllers.model.Prontuario;
import com.aulas.dwbe_atividades_services_controllers.repository.ConsultaRepository;
import com.aulas.dwbe_atividades_services_controllers.repository.MedicoRepository;
import com.aulas.dwbe_atividades_services_controllers.repository.PacienteRepository;
import com.aulas.dwbe_atividades_services_controllers.repository.ProntuarioRepository;

import java.util.List;

public class PacienteService {
    private PacienteRepository pacienteRepository;
    private ProntuarioRepository prontuarioRepository;
    private ConsultaRepository consultaRepository;

    public PacienteService(PacienteRepository pacienteRepository, ProntuarioRepository prontuarioRepository, ConsultaRepository consultaRepository){
        this.pacienteRepository = pacienteRepository;
        this.prontuarioRepository = prontuarioRepository;
        this.consultaRepository = consultaRepository;
    }

    public Paciente salvar(Paciente paciente) {
        Prontuario prontuarioSalvar = paciente.getProntuario();
        Prontuario prontuarioCriado = this.prontuarioRepository.save(prontuarioSalvar);
        paciente.setProntuario(prontuarioCriado);
        Consulta consultaSalvar = (Consulta) paciente.getConsultas();
        Consulta consultaCriado = this.consultaRepository.save(consultaSalvar);
        paciente.setConsultas((List<Consulta>) consultaCriado);
        return this.pacienteRepository.save(paciente);
    }

    public List<Paciente> todos () {
        return this.pacienteRepository.findAll();
    }

    public Paciente porId(Long id) {
        return this.pacienteRepository.findById(id).orElse(null);
    }

    public Paciente atualizar(Long id, Paciente paciente) {
        Paciente pacienteAchar = this.pacienteRepository.findById(id).orElse(null);
        if (pacienteAchar != null) {
            pacienteAchar.setNome(paciente.getNome());
            pacienteAchar.setCpf(pacienteAchar.getCpf());
            pacienteAchar.setTelefone(pacienteAchar.getTelefone());
            pacienteAchar.setProntuario(pacienteAchar.getProntuario());
            pacienteAchar.setConsultas(pacienteAchar.getConsultas());
            return this.pacienteRepository.save(paciente);
        }
        return null;
    }

    public boolean excluir(Long id) {
        this.pacienteRepository.deleteById(id);
        return true;
    }
}
