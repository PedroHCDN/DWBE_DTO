package com.aulas.dwbe_atividades_services_controllers.repository;

import com.aulas.dwbe_atividades_services_controllers.model.Prontuario;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProntuarioRepository extends JpaRepository <Prontuario, Long> {
}
