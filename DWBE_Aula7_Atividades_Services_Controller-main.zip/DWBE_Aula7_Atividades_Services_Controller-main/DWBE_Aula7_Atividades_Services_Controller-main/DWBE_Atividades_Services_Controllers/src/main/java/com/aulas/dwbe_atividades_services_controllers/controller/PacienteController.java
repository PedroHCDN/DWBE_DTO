package com.aulas.dwbe_atividades_services_controllers.controller;

import com.aulas.dwbe_atividades_services_controllers.model.Medico;
import com.aulas.dwbe_atividades_services_controllers.model.Paciente;
import com.aulas.dwbe_atividades_services_controllers.service.MedicoService;
import com.aulas.dwbe_atividades_services_controllers.service.PacienteService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/paciente")
public class PacienteController {

    private PacienteService pacienteService;

    public PacienteController(PacienteService pacienteService) {
        this.pacienteService = pacienteService;
    }

    @PostMapping
    public Paciente salvarPaciente(@RequestBody Paciente paciente) {
        return this.pacienteService.salvar(paciente);
    }

    @GetMapping
    public List<Paciente> todosPaciente() {
        return this.pacienteService.todos();
    }

    @GetMapping("/{id}")
    public Paciente pacientePorId (@PathVariable Long id) {
        return this.pacienteService.porId(id);
    }

    @PutMapping("{id}")
    public Paciente atualizaPaciente(@PathVariable Long id, @RequestBody Paciente paciente) {
        return this.pacienteService.atualizar(id, paciente);
    }

    @DeleteMapping("{id}")
    public boolean excluirPaciente(@PathVariable Long id) {
        return this.pacienteService.excluir(id);
    }
}
