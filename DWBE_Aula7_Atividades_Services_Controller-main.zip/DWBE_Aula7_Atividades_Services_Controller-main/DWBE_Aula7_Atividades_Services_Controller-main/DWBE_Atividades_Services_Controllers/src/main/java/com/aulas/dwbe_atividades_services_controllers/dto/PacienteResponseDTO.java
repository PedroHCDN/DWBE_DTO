package com.aulas.dwbe_atividades_services_controllers.dto;

import com.aulas.dwbe_atividades_services_controllers.model.Consulta;
import com.aulas.dwbe_atividades_services_controllers.model.Prontuario;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class PacienteResponseDTO {
    private Long id;
    private String nome;
    private String cpf;
    private String telefone;
    private Prontuario prontuario;
    private List<Consulta> consultas;
}
