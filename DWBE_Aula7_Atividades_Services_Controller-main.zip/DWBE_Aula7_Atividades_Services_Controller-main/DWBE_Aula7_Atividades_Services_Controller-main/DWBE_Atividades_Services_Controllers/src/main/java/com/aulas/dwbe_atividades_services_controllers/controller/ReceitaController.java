package com.aulas.dwbe_atividades_services_controllers.controller;

import com.aulas.dwbe_atividades_services_controllers.model.Prontuario;
import com.aulas.dwbe_atividades_services_controllers.model.Receita;
import com.aulas.dwbe_atividades_services_controllers.service.ProntuarioService;
import com.aulas.dwbe_atividades_services_controllers.service.ReceitaService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/receita")
public class ReceitaController {
    private ReceitaService receitaService;

    public ReceitaController(ReceitaService receitaService) {
        this.receitaService = receitaService;
    }

    @PostMapping
    public Receita salvarReceita(@RequestBody Receita receita) {
        return this.receitaService.salvar(receita);
    }

    @GetMapping
    public List<Receita> todasReceita() {
        return this.receitaService.todos();
    }

    @GetMapping("/{id}")
    public Receita receitaPorId (@PathVariable Long id) {
        return this.receitaService.porId(id);
    }

    @PutMapping("{id}")
    public Receita atualizaReceita(@PathVariable Long id, @RequestBody Receita receita) {
        return this.receitaService.atualizar(id, receita);
    }

    @DeleteMapping("{id}")
    public boolean excluirReceita(@PathVariable Long id) {
        return this.receitaService.excluir(id);
    }
}
