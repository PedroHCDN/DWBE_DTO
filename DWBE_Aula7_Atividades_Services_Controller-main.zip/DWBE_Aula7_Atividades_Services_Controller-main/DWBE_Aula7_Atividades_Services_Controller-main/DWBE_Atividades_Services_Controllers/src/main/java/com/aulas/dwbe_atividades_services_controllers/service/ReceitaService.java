package com.aulas.dwbe_atividades_services_controllers.service;

import com.aulas.dwbe_atividades_services_controllers.model.Consulta;
import com.aulas.dwbe_atividades_services_controllers.model.Prontuario;
import com.aulas.dwbe_atividades_services_controllers.model.Receita;
import com.aulas.dwbe_atividades_services_controllers.repository.ConsultaRepository;
import com.aulas.dwbe_atividades_services_controllers.repository.ProntuarioRepository;
import com.aulas.dwbe_atividades_services_controllers.repository.ReceitaRepository;

import java.util.List;

public class ReceitaService {
    private ReceitaRepository receitaRepository;
    private ConsultaRepository consultaRepository;

    public ReceitaService(ReceitaRepository receitaRepository, ConsultaRepository consultaRepository){
        this.receitaRepository = receitaRepository;
        this.consultaRepository = consultaRepository;
    }

    public Receita salvar(Receita receita) {

        Consulta consultaSalvar = receita.getConsulta();
        Consulta consultaCriado = this.consultaRepository.save(consultaSalvar);
        receita.setConsulta(consultaCriado);
        return this.receitaRepository.save(receita);

    }

    public List<Receita> todos () {
        return this.receitaRepository.findAll();
    }

    public Receita porId(Long id) {
        return this.receitaRepository.findById(id).orElse(null);
    }

    public Receita atualizar(Long id, Receita receita) {
        Receita receitaAchar = this.receitaRepository.findById(id).orElse(null);
        if (receitaAchar != null) {
            receitaAchar.setMedicamento(receitaAchar.getMedicamento());
            receitaAchar.setDosagem(receitaAchar.getDosagem());
            receitaAchar.setDuracaoDias(receitaAchar.getDuracaoDias());
            receitaAchar.setConsulta(receitaAchar.getConsulta());
            return this.receitaRepository.save(receita);
        }
        return null;
    }

    public boolean excluir(Long id) {
        this.receitaRepository.deleteById(id);
        return true;
    }
}
