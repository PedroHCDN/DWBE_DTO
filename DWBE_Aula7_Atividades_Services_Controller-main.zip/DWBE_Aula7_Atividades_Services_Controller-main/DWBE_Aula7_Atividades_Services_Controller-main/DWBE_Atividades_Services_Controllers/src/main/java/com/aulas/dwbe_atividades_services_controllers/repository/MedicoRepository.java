package com.aulas.dwbe_atividades_services_controllers.repository;

import com.aulas.dwbe_atividades_services_controllers.model.Convenio;
import com.aulas.dwbe_atividades_services_controllers.model.Medico;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MedicoRepository  extends JpaRepository<Medico, Long> {
}
