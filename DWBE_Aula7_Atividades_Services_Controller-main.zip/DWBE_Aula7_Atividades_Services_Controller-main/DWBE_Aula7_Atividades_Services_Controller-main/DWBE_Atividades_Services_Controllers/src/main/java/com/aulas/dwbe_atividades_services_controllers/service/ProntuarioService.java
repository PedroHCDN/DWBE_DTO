package com.aulas.dwbe_atividades_services_controllers.service;

import com.aulas.dwbe_atividades_services_controllers.model.Paciente;
import com.aulas.dwbe_atividades_services_controllers.model.Prontuario;
import com.aulas.dwbe_atividades_services_controllers.repository.PacienteRepository;
import com.aulas.dwbe_atividades_services_controllers.repository.ProntuarioRepository;

import java.util.List;

public class ProntuarioService {
    private ProntuarioRepository prontuarioRepository;

    public ProntuarioService(ProntuarioRepository prontuarioRepository){
        this.prontuarioRepository = prontuarioRepository;
    }

    public Prontuario salvar(Prontuario prontuario) {
        return this.prontuarioRepository.save(prontuario);
    }

    public List<Prontuario> todos () {
        return this.prontuarioRepository.findAll();
    }

    public Prontuario porId(Long id) {
        return this.prontuarioRepository.findById(id).orElse(null);
    }

    public Prontuario atualizar(Long id, Prontuario prontuario) {
        Prontuario prontuarioAchar = this.prontuarioRepository.findById(id).orElse(null);
        if (prontuarioAchar != null) {
            prontuarioAchar.setTipoSanguineo(prontuarioAchar.getTipoSanguineo());
            prontuarioAchar.setAlergia(prontuarioAchar.getAlergia());
            prontuarioAchar.setObservacoes(prontuarioAchar.getObservacoes());
            return this.prontuarioRepository.save(prontuario);
        }
        return null;
    }

    public boolean excluir(Long id) {
        this.prontuarioRepository.deleteById(id);
        return true;
    }
}
