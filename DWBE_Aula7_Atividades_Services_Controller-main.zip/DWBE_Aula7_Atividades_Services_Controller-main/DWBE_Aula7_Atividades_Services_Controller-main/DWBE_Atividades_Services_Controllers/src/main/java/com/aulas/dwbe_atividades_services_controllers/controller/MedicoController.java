package com.aulas.dwbe_atividades_services_controllers.controller;

import com.aulas.dwbe_atividades_services_controllers.model.Convenio;
import com.aulas.dwbe_atividades_services_controllers.model.Medico;
import com.aulas.dwbe_atividades_services_controllers.service.ConvenioService;
import com.aulas.dwbe_atividades_services_controllers.service.MedicoService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/medico")
public class MedicoController {
    private MedicoService medicoService;

    public MedicoController(MedicoService medicoService) {
        this.medicoService = medicoService;
    }

    @PostMapping
    public Medico salvarMedico(@RequestBody Medico medico) {
        return this.medicoService.salvar(medico);
    }

    @GetMapping
    public List<Medico> todosMedicos() {
        return this.medicoService.todos();
    }

    @GetMapping("/{id}")
    public Medico medicoPorId (@PathVariable Long id) {
        return this.medicoService.porId(id);
    }

    @PutMapping("{id}")
    public Medico atualizaMedico(@PathVariable Long id, @RequestBody Medico medico) {
        return this.medicoService.atualizar(id, medico);
    }

    @DeleteMapping("{id}")
    public boolean excluirMedico(@PathVariable Long id) {
        return this.medicoService.excluir(id);
    }
}
