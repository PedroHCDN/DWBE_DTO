package com.aulas.dwbe_atividades_services_controllers.dto;

import com.aulas.dwbe_atividades_services_controllers.model.Consulta;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ReceitaResponseDTO {
    private String medicamento;
    private String dosagem;
    private Integer duracaoDias;
    private Consulta consulta;
}
