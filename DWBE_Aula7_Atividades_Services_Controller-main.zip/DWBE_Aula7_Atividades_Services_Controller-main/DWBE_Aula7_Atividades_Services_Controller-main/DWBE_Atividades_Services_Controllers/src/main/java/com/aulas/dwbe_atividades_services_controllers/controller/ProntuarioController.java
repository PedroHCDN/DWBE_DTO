package com.aulas.dwbe_atividades_services_controllers.controller;

import com.aulas.dwbe_atividades_services_controllers.model.Paciente;
import com.aulas.dwbe_atividades_services_controllers.model.Prontuario;
import com.aulas.dwbe_atividades_services_controllers.service.PacienteService;
import com.aulas.dwbe_atividades_services_controllers.service.ProntuarioService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/prontuario")
public class ProntuarioController {
    private ProntuarioService prontuarioService;

    public ProntuarioController(ProntuarioService prontuarioService) {
        this.prontuarioService = prontuarioService;
    }

    @PostMapping
    public Prontuario salvarProntuario(@RequestBody Prontuario prontuario) {
        return this.prontuarioService.salvar(prontuario);
    }

    @GetMapping
    public List<Prontuario> todosProntuarios() {
        return this.prontuarioService.todos();
    }

    @GetMapping("/{id}")
    public Prontuario prontuarioPorId (@PathVariable Long id) {
        return this.prontuarioService.porId(id);
    }

    @PutMapping("{id}")
    public Prontuario atualizaProntuario(@PathVariable Long id, @RequestBody Prontuario prontuario) {
        return this.prontuarioService.atualizar(id, prontuario);
    }

    @DeleteMapping("{id}")
    public boolean excluirProntuario(@PathVariable Long id) {
        return this.prontuarioService.excluir(id);
    }
}
