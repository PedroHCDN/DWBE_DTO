package com.aulas.dwbe_atividades_services_controllers.repository;

import com.aulas.dwbe_atividades_services_controllers.model.Paciente;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PacienteRepository extends JpaRepository<Paciente, Long> {
}
