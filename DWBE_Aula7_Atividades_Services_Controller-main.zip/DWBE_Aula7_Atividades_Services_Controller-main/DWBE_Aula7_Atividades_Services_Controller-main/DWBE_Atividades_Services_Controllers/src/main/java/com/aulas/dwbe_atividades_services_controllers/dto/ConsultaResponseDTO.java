package com.aulas.dwbe_atividades_services_controllers.dto;

import com.aulas.dwbe_atividades_services_controllers.model.Convenio;
import com.aulas.dwbe_atividades_services_controllers.model.Medico;
import com.aulas.dwbe_atividades_services_controllers.model.Paciente;
import lombok.Builder;
import lombok.Data;

import java.util.Date;

@Data
@Builder
public class ConsultaResponseDTO {
    private Long id;
    private Date dataHora;
    private String motivo;
    private Double valor;
    private Paciente paciente;
    private Medico medico;
    private Convenio convenio;
}
