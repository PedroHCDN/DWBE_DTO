package com.aulas.dwbe_atividades_services_controllers.dto;

import com.aulas.dwbe_atividades_services_controllers.model.Convenio;
import com.aulas.dwbe_atividades_services_controllers.model.Medico;
import com.aulas.dwbe_atividades_services_controllers.model.Paciente;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ConsultaRequestDTO {
    private Date dataHora;
    private String motivo;
    private Double valor;
    private Paciente paciente;
    private Medico medico;
    private Convenio convenio;
}
