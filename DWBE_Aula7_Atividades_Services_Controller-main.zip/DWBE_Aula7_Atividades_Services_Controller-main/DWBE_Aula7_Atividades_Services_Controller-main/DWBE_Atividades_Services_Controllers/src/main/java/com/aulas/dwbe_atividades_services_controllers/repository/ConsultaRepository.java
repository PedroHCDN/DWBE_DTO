package com.aulas.dwbe_atividades_services_controllers.repository;

import com.aulas.dwbe_atividades_services_controllers.model.Consulta;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ConsultaRepository extends JpaRepository<Consulta, Long> {
}
