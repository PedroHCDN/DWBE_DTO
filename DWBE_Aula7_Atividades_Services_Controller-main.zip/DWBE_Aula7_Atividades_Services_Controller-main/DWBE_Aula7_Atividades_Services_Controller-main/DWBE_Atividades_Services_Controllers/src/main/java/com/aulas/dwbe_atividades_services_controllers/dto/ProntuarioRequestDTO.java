package com.aulas.dwbe_atividades_services_controllers.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProntuarioRequestDTO {
    private String tipoSanguineo;
    private String alergia;
    private String observacoes;
}
