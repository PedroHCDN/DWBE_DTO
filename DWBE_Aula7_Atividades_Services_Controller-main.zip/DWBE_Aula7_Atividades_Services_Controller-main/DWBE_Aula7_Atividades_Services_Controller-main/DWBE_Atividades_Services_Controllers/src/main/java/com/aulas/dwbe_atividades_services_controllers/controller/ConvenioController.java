package com.aulas.dwbe_atividades_services_controllers.controller;

import com.aulas.dwbe_atividades_services_controllers.model.Consulta;
import com.aulas.dwbe_atividades_services_controllers.model.Convenio;
import com.aulas.dwbe_atividades_services_controllers.service.ConsultaService;
import com.aulas.dwbe_atividades_services_controllers.service.ConvenioService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/convenio")
public class ConvenioController {
    private ConvenioService convenioService;

    public ConvenioController(ConvenioService convenioService) {
        this.convenioService = convenioService;
    }

    @PostMapping
    public Convenio salvarConvenio(@RequestBody Convenio convenio) {
        return this.convenioService.salvar(convenio);
    }

    @GetMapping
    public List<Convenio> todosConvenios() {
        return this.convenioService.todos();
    }

    @GetMapping("/{id}")
    public Convenio convenioPorId (@PathVariable Long id) {
        return this.convenioService.porId(id);
    }

    @PutMapping("{id}")
    public Convenio atualizaConvenio(@PathVariable Long id, @RequestBody Convenio convenio) {
        return this.convenioService.atualizar(id, convenio);
    }

    @DeleteMapping("{id}")
    public boolean excluirConvenio(@PathVariable Long id) {
        return this.convenioService.excluir(id);
    }
}
